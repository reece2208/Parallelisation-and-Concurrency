Source files are in \src
.git repo included
Source files must be run with arguments
.bat file to easy compile for Windows
MakeFile is aslo included in \src 
Report Included

Thanks

Reece Gounden
GNDREE002