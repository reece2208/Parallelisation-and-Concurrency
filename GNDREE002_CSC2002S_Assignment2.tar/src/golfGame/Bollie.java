package golfGame;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Reece
 */
public class Bollie extends Thread {

    private AtomicBoolean done;  // flag to indicate when threads should stop

    private BallStash sharedStash; //link to shared stash
    private Range sharedField; //link to shared field
    private Random waitTime;
    private int noCollected = 0;

    //link to shared field
    Bollie(BallStash stash, Range field, AtomicBoolean doneFlag) {
        sharedStash = stash; //shared 
        sharedField = field; //shared
        waitTime = new Random();
        done = doneFlag;
    }

    public void run() {

        //while True
        golfBall[] ballsCollected = new golfBall[sharedStash.getSizeStash()];
        while (done.get() != true) {
            try {
                sharedField.setCartStatus(true);
                sleep(1000);
                System.out.println("*********** Bollie collecting balls   ************");
                ballsCollected = sharedField.collectAllBallsFromField(ballsCollected);

                for (int i = 0; i < ballsCollected.length; i++) {
                    if (ballsCollected[i] != null) {
                        noCollected++;
                    }
                }
                System.out.println("Balls Added to stash = " + noCollected);
                // collect balls, no golfers allowed to swing while this is happening
                sleep(1000);
                sharedField.setCartStatus(false);
                System.out.println("*********** Bollie adding balls to stash ************");
                sharedStash.addBallsToStash(ballsCollected, noCollected);

                noCollected = 0;
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }
}
