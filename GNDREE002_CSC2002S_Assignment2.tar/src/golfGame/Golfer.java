package golfGame;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Reece
 */
public class Golfer extends Thread {

    //remeber to ensure thread saftey
    private AtomicBoolean done;
    private AtomicBoolean cartOnField;

    private static int noGolfers; //shared amoungst threads
    private static int ballsPerBucket = 4; //shared amoungst threads

    private int myID;

    private golfBall[] golferBucket;
    private BallStash sharedStash; //link to shared stash
    private Range sharedField; //link to shared field
    private Random swingTime;

    Golfer(BallStash stash, Range field, AtomicBoolean cartFlag, AtomicBoolean doneFlag) {
        sharedStash = stash; //shared 
        sharedField = field; //shared
        cartOnField = cartFlag; //shared
        done = doneFlag;
        golferBucket = new golfBall[ballsPerBucket];
        swingTime = new Random();
        myID = newGolfID();
    }

    /**
     *
     * @return
     */
    synchronized public static int newGolfID() {
        noGolfers++;
        return noGolfers;
    }

    /**
     *
     * @param noBalls
     */
    public static void setBallsPerBucket(int noBalls) {
        ballsPerBucket = noBalls;
    }

    /**
     *
     * @return
     */
    public static int getBallsPerBucket() {
        return ballsPerBucket;
    }

    public void run() {

        while (done.get() != true) {

            try {

                System.out.println(">>> Golfer #" + myID + " trying to fill bucket with " + getBallsPerBucket() + " balls.");
                golferBucket = sharedStash.getBucketBalls();
                if (done.get()) {
                    System.out.println("Golfer " + myID + " cannot get balls its closing time");
                    break;
                }
                System.out.println("<<< Golfer #" + myID + " filled bucket with " + getBallsPerBucket() + " balls. Balls remaining: " + sharedStash.getBallsInStash());

                for (int b = 0; b < ballsPerBucket; b++) { //for every ball in bucket
                    try {

                        while (sharedField.getCartStatus()) {
                            System.out.print("");
                        }
                        sleep(swingTime.nextInt(2000));
                        sharedField.hitBallOntoField(golferBucket[b]);
                        System.out.println("Golfer #" + myID + " hit ball #" + golferBucket[b].getID() + " onto field");

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } //      swing
                }

                    //wait loop
                    //!!wair for cart if necessary if cart there
            } catch (InterruptedException ex) {
                Logger.getLogger(Golfer.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        System.out.println("Golfer " + myID + " left");
    }
}
