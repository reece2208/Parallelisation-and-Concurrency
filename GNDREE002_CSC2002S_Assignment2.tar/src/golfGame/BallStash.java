package golfGame;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 *
 * @author Reece
 */
public class BallStash {

    //static variables
    private static int sizeStash = 20;
    private static int sizeBucket = 4;
    
    //ADD variables: a collection of golf balls, called stash
     static ArrayBlockingQueue<golfBall> stash;
     
        BallStash() {
        stash = new ArrayBlockingQueue<>(sizeStash);
    }

    //ADD methods:
    //getBucketBalls

    /**
     *
     * @return
     * @throws InterruptedException
     */
         public golfBall[] getBucketBalls() throws InterruptedException {
        int temp=sizeStash;
        golfBall[] a = new golfBall[sizeBucket];
        for (int i = 0; i < sizeBucket; i++) {
            a[i] = stash.take();
        }
        return a;
    }

    // addBallsToStash

    /**
     *
     * @param balls
     * @param noCollected
     * @throws InterruptedException
     */
         public void addBallsToStash(golfBall[] balls, int noCollected) throws InterruptedException {
        int temp=stash.size();
        for (golfBall ball : balls) {
            if(ball!=null){
            stash.put(ball);
            }
        }
    }

    // getBallsInStash - return number of balls in the stash
    synchronized int getBallsInStash() {
        return stash.size();
    }
    //getters and setters for static variables - you need to edit these

    /**
     *
     * @param noBalls
     */
        public static void setSizeBucket(int noBalls) {
        sizeBucket = noBalls;
    }

    /**
     *
     * @return
     */
     public static int getSizeBucket() {
        return sizeBucket;
    }

    /**
     *
     * @param noBalls
     */
    synchronized public static void setSizeStash(int noBalls) {
        sizeStash = noBalls;
   
    }

    /**
     *
     * @return
     */
    synchronized public static int getSizeStash() {
        return sizeStash;
    }

}
