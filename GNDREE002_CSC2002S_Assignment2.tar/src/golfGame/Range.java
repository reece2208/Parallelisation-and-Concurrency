package golfGame;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Reece
 */
public class Range {

    private static int sizeStash = 20;
    private AtomicBoolean cartOnField;

    //ADD variable: ballsOnField collection;
    ArrayBlockingQueue<golfBall> ballsOnField;

    //Add constructors
    Range(int size) {
        sizeStash = size;
        ballsOnField = new ArrayBlockingQueue<>(size);
        cartOnField = new AtomicBoolean(false);
    }

    //ADD method: collectAllBallsFromField(golfBall [] ballsCollected) 
    synchronized golfBall[] collectAllBallsFromField(golfBall[] ballsCollected) throws InterruptedException {
        ballsOnField.toArray(ballsCollected);
        ballsOnField.clear();
        return ballsCollected;
    }

    //ADD method: hitBallOntoField(golfBall ball) 
    synchronized void hitBallOntoField(golfBall ball) throws InterruptedException {
        ballsOnField.put(ball);
        //System.out.println(ballsOnField.size());
    }

    /**
     *get status of cart on field
     * @return
     */
    synchronized public boolean getCartStatus() {
        return cartOnField.get();
    }

    /**
     *set status of cart on field
     * @param status
     */
    public void setCartStatus(boolean status) {
        cartOnField.getAndSet(status);
    }

}
