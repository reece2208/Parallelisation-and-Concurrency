Source files are in \src
.git repo included
Source files must be run with arguments
.bat files included with source files are to show how the results of testing were collated
MakeFile is included in \src
The Excel file 'Raw Data' contains all of the data the report is based on, not all the data was used
as it would have been redundant and unnecessary. I left it there to show that comprehensive testing was done

Thanks