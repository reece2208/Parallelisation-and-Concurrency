
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Median Filter Sequential Data
 *
 * @author Reece
 */
public class MedianFilter {

    static String infile, outfile;
    static int fsize, lines;
    static float[] values, clean;
    static float totalt;

    public static void main(String[] args) {

        infile = args[0];
        fsize = Integer.parseInt(args[1]);
        outfile = args[2];
        if (!checkOdd(fsize)) {
            System.out.println("*Please enter an odd number >=3 and <=21 for filter size*");
        } else {
            MedianFilter a = new MedianFilter();
            a.read();
            long start = System.currentTimeMillis();
            a.clean(values, fsize);
            totalt=((System.currentTimeMillis() - start) / 1000.0f);
            System.out.println("Total time: " + totalt);
            a.write(outfile, clean);
        }

    }

    static boolean checkOdd(int filt) {
        if (filt % 2 == 0 || filt < 3 || filt > 21) {
            return false;
        }
        return true;
    }

    void read() { //method to read and load vaules into array from file
        try {
            Scanner rd = new Scanner(new File(infile + ".txt"));
            lines = Integer.parseInt(rd.nextLine());
            values = new float[lines + 1]; //array of input values
            clean = new float[lines + 1]; //array output values
            for (int i = 0; i < lines; i++) {
                String[] cval = rd.nextLine().split(" ");
                values[Integer.parseInt(cval[0])] = Float.parseFloat(cval[1]); //load values into array
                //System.out.println(values[i + 1]);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MedianFilter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void clean(float[] dirty, int fsize) { //method to filter the 'dirty' data
        int bord = (fsize - 1) / 2; //border length
        float[] sub = new float[fsize]; //subarray of size of filter
        for (int i = bord + 1; i <= dirty.length - bord - 1; i++) {//where the magic happens
            clean[i] = Median(Arrays.copyOfRange(dirty, i - bord, i + bord + 1));

        }
        //extra for loops to populate the borders
        for (int i = 1; i < bord + 1; i++) {
            clean[i] = dirty[i];
        }
        for (int i = dirty.length - bord; i < dirty.length; i++) {
            clean[i] = dirty[i];
        }
    }

    float Median(float[] sub) { //method to calculate and output the median of a subset
        //System.out.println(Arrays.toString(sub));
        Arrays.sort(sub);
        //System.out.println((int)Math.floor(sub.length/2));
        return sub[(int) Math.floor(sub.length / 2)];

    }

    void write(String file, float[] clean) { //method to write the cleaned data to file
        PrintWriter wr = null;
        PrintWriter res=null;
        try {
            wr = new PrintWriter(new FileWriter(file + ".txt"));
            res= new PrintWriter(new FileWriter("SerialResults.txt",true));
            wr.println(lines);
            for (int i = 1; i < values.length; i++) {
                wr.println(i + " " + clean[i]);
            }
            res.println(lines+" "+totalt+" "+fsize);
            wr.close();
            res.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MedianFilter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MedianFilter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
