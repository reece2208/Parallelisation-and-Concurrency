
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.ForkJoinPool;

/**
 * Median Filter Sequential Data
 *
 * @author Reece
 */
public class MedianFilterParallel {

    static String infile, outfile;
    static int fsize, lines, bord;
    static float[] values;
    static float totalt; 
   //float[] clean;

    public static void main(String[] args) {

        infile = args[0];
        fsize = Integer.parseInt(args[1]);
        outfile = args[2];
        bord = (fsize-1) / 2;

        ForkJoinPool pool = new ForkJoinPool();
        if (!checkOdd(fsize)) {
        } else {
            
            read();
            float[] clean = new float[lines + 1];
            long start = System.currentTimeMillis();
            pool.invoke(new Median(1 + bord, values.length - bord - 1, clean,values,fsize,bord,lines));
            for (int i = 1; i < bord + 1; i++) {
                clean[i] = values[i];
            }
            for (int i = values.length - bord; i < values.length; i++) {
                clean[i] = values[i];
            }
            totalt=(System.currentTimeMillis() - start) / 1000.0f;
            System.out.println("Time: " +totalt );
            write(outfile, clean);
        }

    }


    static boolean checkOdd(int filt) {
        if (filt % 2 == 0 || filt < 3 || filt > 21) {
            return false;
        }
        return true;
    }

    static void read() { //method to read and load vaules into array from file
        try {
            Scanner rd = new Scanner(new File(infile + ".txt"));
            lines = Integer.parseInt(rd.nextLine());
            values = new float[lines + 1]; //array of input values
            //clean = new float[lines + 1]; //array output values
            for (int i = 0; i < lines; i++) {
                String[] cval = rd.nextLine().split(" ");
                values[Integer.parseInt(cval[0])] = Float.parseFloat(cval[1]); //load values into array
                //System.out.println(values[i + 1]);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MedianFilter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static void write(String file, float[] clean) { //method to write the cleaned data to file
        PrintWriter wr = null;
        PrintWriter res =null;
        try {
            wr = new PrintWriter(new FileWriter(file + ".txt"));
            res = new PrintWriter(new FileWriter("ParallelResults.txt",true));
            wr.println(lines);
            for (int i = 1; i < values.length; i++) {
                wr.println(i + " " + clean[i]);
            }
            res.println(lines+" "+totalt+" "+fsize);
            res.close();
            wr.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MedianFilter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MedianFilterParallel.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
