
import java.util.Arrays;
import java.util.concurrent.RecursiveAction;

/**
 *
 * @author Reece
 */
public class Median extends RecursiveAction {

    int fsize, lines, lo, hi, bord;
    final int SEQUENTIAL_CUTOFF = 500;
    float[] sub,clean,values;

    Median(int l, int h,float[] clean,float[] values,int fsize,int bord,int lines) {
        this.hi = h;//args
        this.lo = l;
        this.fsize =fsize ;
        this.lines = lines;
        this.bord = bord; //border length
        this.clean=clean;
        this.values=values;
    }

    void computeDirectly() { //method to filter the 'dirty' data
        for (int i = lo; i <= hi; i++) {//where the filtering happens
            float[] sub=Arrays.copyOfRange(values, i-bord,i+bord+1);
            Arrays.sort(sub);
            clean[i]=sub[(int)Math.floor(sub.length / 2)];
        }
    }

    @Override
    protected void compute() {
        if ((hi - lo) < SEQUENTIAL_CUTOFF) {
            computeDirectly();
            
        } else {
            Median left = new Median(lo,(hi+lo)/2,clean,values,fsize,bord,lines);
            Median right = new Median((hi+lo)/2,hi,clean,values,fsize,bord,lines);
            left.fork();
            right.compute();
            left.join();
        }
    }

}
